const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Database connection
const sqlite3 = require('sqlite3').verbose();
const dbPath = path.join(__dirname, '../medical_app.db');
const db = new sqlite3.Database(dbPath);

// Routes
app.get('/', (req, res) => {
  res.json({
    message: 'Medical App API Server',
    version: '1.0.0',
    endpoints: {
      patients: '/api/patients',
      appointments: '/api/appointments',
      conditions: '/api/conditions',
      diagnoses: '/api/diagnoses',
      medications: '/api/medications'
    }
  });
});

// Patients endpoints
app.get('/api/patients', (req, res) => {
  const { search, limit = 50 } = req.query;
  
  let query = 'SELECT * FROM patients';
  let params = [];

  if (search) {
    query += ' WHERE first_name LIKE ? OR last_name LIKE ?';
    params = [`%${search}%`, `%${search}%`];
  }

  query += ' LIMIT ?';
  params.push(parseInt(limit));

  db.all(query, params, (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows);
    }
  });
});

app.get('/api/patients/:id', (req, res) => {
  const { id } = req.params;
  
  db.get('SELECT * FROM patients WHERE patient_id = ?', [id], (err, row) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else if (!row) {
      res.status(404).json({ error: 'Patient not found' });
    } else {
      res.json(row);
    }
  });
});

// Appointments endpoints
app.get('/api/appointments', (req, res) => {
  const { patient_id, date_from, date_to, status } = req.query;
  
  let query = 'SELECT * FROM appointments WHERE 1=1';
  let params = [];

  if (patient_id) {
    query += ' AND patient_id = ?';
    params.push(patient_id);
  }

  if (date_from) {
    query += ' AND appointment_date >= ?';
    params.push(date_from);
  }

  if (date_to) {
    query += ' AND appointment_date <= ?';
    params.push(date_to);
  }

  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }

  query += ' ORDER BY appointment_date, appointment_time';

  db.all(query, params, (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows);
    }
  });
});

app.post('/api/appointments', (req, res) => {
  const {
    patient_id,
    doctor_name,
    doctor_specialty,
    appointment_date,
    appointment_time,
    appointment_type,
    reason_for_visit,
    notes
  } = req.body;

  if (!patient_id || !doctor_name || !appointment_date || !appointment_time) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const appointmentId = 'A' + Date.now().toString().slice(-6);
  
  const query = `
    INSERT INTO appointments (
      appointment_id, patient_id, doctor_name, doctor_specialty,
      appointment_date, appointment_time, appointment_type,
      status, reason_for_visit, notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  
  const params = [
    appointmentId,
    patient_id,
    doctor_name,
    doctor_specialty || null,
    appointment_date,
    appointment_time,
    appointment_type || 'consultation',
    'scheduled',
    reason_for_visit || null,
    notes || null
  ];

  db.run(query, params, function(err) {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json({
        appointment_id: appointmentId,
        message: 'Appointment created successfully'
      });
    }
  });
});

// Conditions endpoints
app.get('/api/conditions', (req, res) => {
  const { patient_id, status } = req.query;
  
  if (!patient_id) {
    return res.status(400).json({ error: 'patient_id is required' });
  }

  let query = 'SELECT * FROM conditions WHERE patient_id = ?';
  let params = [patient_id];

  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }

  query += ' ORDER BY diagnosis_date DESC';

  db.all(query, params, (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows);
    }
  });
});

// Diagnoses endpoints
app.get('/api/diagnoses', (req, res) => {
  const { patient_id, date_from, date_to } = req.query;
  
  if (!patient_id) {
    return res.status(400).json({ error: 'patient_id is required' });
  }

  let query = 'SELECT * FROM diagnoses WHERE patient_id = ?';
  let params = [patient_id];

  if (date_from) {
    query += ' AND diagnosis_date >= ?';
    params.push(date_from);
  }

  if (date_to) {
    query += ' AND diagnosis_date <= ?';
    params.push(date_to);
  }

  query += ' ORDER BY diagnosis_date DESC';

  db.all(query, params, (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows);
    }
  });
});

// Medications endpoints
app.get('/api/medications', (req, res) => {
  const { patient_id, active_only } = req.query;
  
  if (!patient_id) {
    return res.status(400).json({ error: 'patient_id is required' });
  }

  let query = 'SELECT * FROM medications WHERE patient_id = ?';
  let params = [patient_id];

  if (active_only === 'true') {
    query += ' AND (end_date IS NULL OR end_date > date("now"))';
  }

  query += ' ORDER BY start_date DESC';

  db.all(query, params, (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows);
    }
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start server
app.listen(PORT, () => {
  console.log(`Medical App API Server running on port ${PORT}`);
  console.log(`Access the API at http://localhost:${PORT}`);
  console.log(`API Documentation available at http://localhost:${PORT}/`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down server...');
  db.close((err) => {
    if (err) {
      console.error('Error closing database:', err.message);
    } else {
      console.log('Database connection closed');
    }
    process.exit(0);
  });
});
