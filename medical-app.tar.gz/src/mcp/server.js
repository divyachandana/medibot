const { Server } = require('@modelcontextprotocol/sdk/server/index.js');
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
const {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} = require('@modelcontextprotocol/sdk/types.js');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

class MedicalAppMCPServer {
  constructor() {
    this.server = new Server(
      {
        name: 'medical-app-mcp',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.dbPath = path.join(__dirname, '../../medical_app.db');
    this.db = null;
    this.setupToolHandlers();
  }

  async connectDatabase() {
    return new Promise((resolve, reject) => {
      this.db = new sqlite3.Database(this.dbPath, (err) => {
        if (err) {
          console.error('Error opening database:', err.message);
          reject(err);
        } else {
          console.log('Connected to medical database');
          resolve();
        }
      });
    });
  }

  setupToolHandlers() {
    // List available tools
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      return {
        tools: [
          {
            name: 'get_patient',
            description: 'Get patient information by patient ID',
            inputSchema: {
              type: 'object',
              properties: {
                patient_id: {
                  type: 'string',
                  description: 'The patient ID to retrieve information for',
                },
              },
              required: ['patient_id'],
            },
          },
          {
            name: 'get_patients',
            description: 'Get all patients or search patients by name',
            inputSchema: {
              type: 'object',
              properties: {
                search: {
                  type: 'string',
                  description: 'Optional search term for patient name',
                },
                limit: {
                  type: 'number',
                  description: 'Maximum number of patients to return (default: 50)',
                },
              },
            },
          },
          {
            name: 'get_appointments',
            description: 'Get appointments for a patient or all appointments',
            inputSchema: {
              type: 'object',
              properties: {
                patient_id: {
                  type: 'string',
                  description: 'Optional patient ID to filter appointments',
                },
                date_from: {
                  type: 'string',
                  description: 'Start date for appointment range (YYYY-MM-DD)',
                },
                date_to: {
                  type: 'string',
                  description: 'End date for appointment range (YYYY-MM-DD)',
                },
                status: {
                  type: 'string',
                  description: 'Filter by appointment status (scheduled, completed, cancelled)',
                },
              },
            },
          },
          {
            name: 'get_conditions',
            description: 'Get medical conditions for a patient',
            inputSchema: {
              type: 'object',
              properties: {
                patient_id: {
                  type: 'string',
                  description: 'Patient ID to get conditions for',
                },
                status: {
                  type: 'string',
                  description: 'Filter by condition status (active, managed, resolved)',
                },
              },
              required: ['patient_id'],
            },
          },
          {
            name: 'get_diagnoses',
            description: 'Get diagnoses for a patient',
            inputSchema: {
              type: 'object',
              properties: {
                patient_id: {
                  type: 'string',
                  description: 'Patient ID to get diagnoses for',
                },
                date_from: {
                  type: 'string',
                  description: 'Start date for diagnosis range (YYYY-MM-DD)',
                },
                date_to: {
                  type: 'string',
                  description: 'End date for diagnosis range (YYYY-MM-DD)',
                },
              },
              required: ['patient_id'],
            },
          },
          {
            name: 'get_medications',
            description: 'Get medications for a patient',
            inputSchema: {
              type: 'object',
              properties: {
                patient_id: {
                  type: 'string',
                  description: 'Patient ID to get medications for',
                },
                active_only: {
                  type: 'boolean',
                  description: 'Only return active medications (no end date)',
                },
              },
              required: ['patient_id'],
            },
          },
          {
            name: 'create_appointment',
            description: 'Create a new appointment',
            inputSchema: {
              type: 'object',
              properties: {
                patient_id: {
                  type: 'string',
                  description: 'Patient ID for the appointment',
                },
                doctor_name: {
                  type: 'string',
                  description: 'Name of the doctor',
                },
                doctor_specialty: {
                  type: 'string',
                  description: 'Doctor specialty',
                },
                appointment_date: {
                  type: 'string',
                  description: 'Appointment date (YYYY-MM-DD)',
                },
                appointment_time: {
                  type: 'string',
                  description: 'Appointment time (HH:MM:SS)',
                },
                appointment_type: {
                  type: 'string',
                  description: 'Type of appointment (consultation, follow-up, procedure)',
                },
                reason_for_visit: {
                  type: 'string',
                  description: 'Reason for the visit',
                },
                notes: {
                  type: 'string',
                  description: 'Additional notes',
                },
              },
              required: ['patient_id', 'doctor_name', 'appointment_date', 'appointment_time'],
            },
          },
          {
            name: 'update_appointment',
            description: 'Update an existing appointment',
            inputSchema: {
              type: 'object',
              properties: {
                appointment_id: {
                  type: 'string',
                  description: 'ID of the appointment to update',
                },
                status: {
                  type: 'string',
                  description: 'New status (scheduled, completed, cancelled)',
                },
                notes: {
                  type: 'string',
                  description: 'Updated notes',
                },
              },
              required: ['appointment_id'],
            },
          },
        ],
      };
    });

    // Handle tool calls
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      try {
        switch (name) {
          case 'get_patient':
            return await this.getPatient(args.patient_id);
          case 'get_patients':
            return await this.getPatients(args.search, args.limit);
          case 'get_appointments':
            return await this.getAppointments(args);
          case 'get_conditions':
            return await this.getConditions(args.patient_id, args.status);
          case 'get_diagnoses':
            return await this.getDiagnoses(args);
          case 'get_medications':
            return await this.getMedications(args.patient_id, args.active_only);
          case 'create_appointment':
            return await this.createAppointment(args);
          case 'update_appointment':
            return await this.updateAppointment(args);
          default:
            throw new Error(`Unknown tool: ${name}`);
        }
      } catch (error) {
        return {
          content: [
            {
              type: 'text',
              text: `Error: ${error.message}`,
            },
          ],
        };
      }
    });
  }

  async getPatient(patientId) {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM patients WHERE patient_id = ?';
      this.db.get(query, [patientId], (err, row) => {
        if (err) {
          reject(err);
        } else if (!row) {
          resolve({
            content: [
              {
                type: 'text',
                text: `Patient with ID ${patientId} not found`,
              },
            ],
          });
        } else {
          resolve({
            content: [
              {
                type: 'text',
                text: JSON.stringify(row, null, 2),
              },
            ],
          });
        }
      });
    });
  }

  async getPatients(search, limit = 50) {
    return new Promise((resolve, reject) => {
      let query = 'SELECT * FROM patients';
      let params = [];

      if (search) {
        query += ' WHERE first_name LIKE ? OR last_name LIKE ?';
        params = [`%${search}%`, `%${search}%`];
      }

      query += ' LIMIT ?';
      params.push(limit);

      this.db.all(query, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve({
            content: [
              {
                type: 'text',
                text: JSON.stringify(rows, null, 2),
              },
            ],
          });
        }
      });
    });
  }

  async getAppointments(args) {
    return new Promise((resolve, reject) => {
      let query = 'SELECT * FROM appointments WHERE 1=1';
      let params = [];

      if (args.patient_id) {
        query += ' AND patient_id = ?';
        params.push(args.patient_id);
      }

      if (args.date_from) {
        query += ' AND appointment_date >= ?';
        params.push(args.date_from);
      }

      if (args.date_to) {
        query += ' AND appointment_date <= ?';
        params.push(args.date_to);
      }

      if (args.status) {
        query += ' AND status = ?';
        params.push(args.status);
      }

      query += ' ORDER BY appointment_date, appointment_time';

      this.db.all(query, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve({
            content: [
              {
                type: 'text',
                text: JSON.stringify(rows, null, 2),
              },
            ],
          });
        }
      });
    });
  }

  async getConditions(patientId, status) {
    return new Promise((resolve, reject) => {
      let query = 'SELECT * FROM conditions WHERE patient_id = ?';
      let params = [patientId];

      if (status) {
        query += ' AND status = ?';
        params.push(status);
      }

      query += ' ORDER BY diagnosis_date DESC';

      this.db.all(query, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve({
            content: [
              {
                type: 'text',
                text: JSON.stringify(rows, null, 2),
              },
            ],
          });
        }
      });
    });
  }

  async getDiagnoses(args) {
    return new Promise((resolve, reject) => {
      let query = 'SELECT * FROM diagnoses WHERE patient_id = ?';
      let params = [args.patient_id];

      if (args.date_from) {
        query += ' AND diagnosis_date >= ?';
        params.push(args.date_from);
      }

      if (args.date_to) {
        query += ' AND diagnosis_date <= ?';
        params.push(args.date_to);
      }

      query += ' ORDER BY diagnosis_date DESC';

      this.db.all(query, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve({
            content: [
              {
                type: 'text',
                text: JSON.stringify(rows, null, 2),
              },
            ],
          });
        }
      });
    });
  }

  async getMedications(patientId, activeOnly = false) {
    return new Promise((resolve, reject) => {
      let query = 'SELECT * FROM medications WHERE patient_id = ?';
      let params = [patientId];

      if (activeOnly) {
        query += ' AND (end_date IS NULL OR end_date > date("now"))';
      }

      query += ' ORDER BY start_date DESC';

      this.db.all(query, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve({
            content: [
              {
                type: 'text',
                text: JSON.stringify(rows, null, 2),
              },
            ],
          });
        }
      });
    });
  }

  async createAppointment(args) {
    return new Promise((resolve, reject) => {
      const { v4: uuidv4 } = require('uuid');
      const appointmentId = 'A' + Date.now().toString().slice(-6);
      
      const query = `
        INSERT INTO appointments (
          appointment_id, patient_id, doctor_name, doctor_specialty,
          appointment_date, appointment_time, appointment_type,
          status, reason_for_visit, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      const params = [
        appointmentId,
        args.patient_id,
        args.doctor_name,
        args.doctor_specialty || null,
        args.appointment_date,
        args.appointment_time,
        args.appointment_type || 'consultation',
        'scheduled',
        args.reason_for_visit || null,
        args.notes || null
      ];

      this.db.run(query, params, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve({
            content: [
              {
                type: 'text',
                text: `Appointment created successfully with ID: ${appointmentId}`,
              },
            ],
          });
        }
      });
    });
  }

  async updateAppointment(args) {
    return new Promise((resolve, reject) => {
      let query = 'UPDATE appointments SET updated_at = CURRENT_TIMESTAMP';
      let params = [];

      if (args.status) {
        query += ', status = ?';
        params.push(args.status);
      }

      if (args.notes) {
        query += ', notes = ?';
        params.push(args.notes);
      }

      query += ' WHERE appointment_id = ?';
      params.push(args.appointment_id);

      this.db.run(query, params, function(err) {
        if (err) {
          reject(err);
        } else if (this.changes === 0) {
          resolve({
            content: [
              {
                type: 'text',
                text: `Appointment with ID ${args.appointment_id} not found`,
              },
            ],
          });
        } else {
          resolve({
            content: [
              {
                type: 'text',
                text: `Appointment ${args.appointment_id} updated successfully`,
              },
            ],
          });
        }
      });
    });
  }

  async start() {
    await this.connectDatabase();
    
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.log('Medical App MCP Server started');
  }
}

// Start the server if this file is run directly
if (require.main === module) {
  const server = new MedicalAppMCPServer();
  server.start().catch(console.error);
}

module.exports = MedicalAppMCPServer;
