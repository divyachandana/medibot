const sqlite3 = require('sqlite3').verbose();
const { v4: uuidv4 } = require('uuid');
const path = require('path');

// Database file path
const dbPath = path.join(__dirname, '../../medical_app.db');

// Create database connection
const db = new sqlite3.Database(dbPath);

// Sample patient data
const patients = [
    {
        patient_id: 'P001',
        first_name: 'John',
        last_name: 'Smith',
        date_of_birth: '1985-03-15',
        gender: 'Male',
        phone: '555-0101',
        email: 'john.smith@email.com',
        address: '123 Main St, Anytown, ST 12345',
        emergency_contact_name: 'Jane Smith',
        emergency_contact_phone: '555-0102',
        insurance_provider: 'HealthPlus Insurance',
        insurance_number: 'HP123456789'
    },
    {
        patient_id: 'P002',
        first_name: 'Sarah',
        last_name: 'Johnson',
        date_of_birth: '1990-07-22',
        gender: 'Female',
        phone: '555-0201',
        email: 'sarah.johnson@email.com',
        address: '456 Oak Ave, Anytown, ST 12345',
        emergency_contact_name: 'Mike Johnson',
        emergency_contact_phone: '555-0202',
        insurance_provider: 'MediCare Plus',
        insurance_number: 'MP987654321'
    },
    {
        patient_id: 'P003',
        first_name: 'Robert',
        last_name: 'Brown',
        date_of_birth: '1978-11-08',
        gender: 'Male',
        phone: '555-0301',
        email: 'robert.brown@email.com',
        address: '789 Pine St, Anytown, ST 12345',
        emergency_contact_name: 'Lisa Brown',
        emergency_contact_phone: '555-0302',
        insurance_provider: 'Blue Cross Blue Shield',
        insurance_number: 'BC123789456'
    },
    {
        patient_id: 'P004',
        first_name: 'Emily',
        last_name: 'Davis',
        date_of_birth: '1995-01-30',
        gender: 'Female',
        phone: '555-0401',
        email: 'emily.davis@email.com',
        address: '321 Elm St, Anytown, ST 12345',
        emergency_contact_name: 'David Davis',
        emergency_contact_phone: '555-0402',
        insurance_provider: 'Aetna Health',
        insurance_number: 'AH456789123'
    },
    {
        patient_id: 'P005',
        first_name: 'Michael',
        last_name: 'Wilson',
        date_of_birth: '1982-09-12',
        gender: 'Male',
        phone: '555-0501',
        email: 'michael.wilson@email.com',
        address: '654 Maple Dr, Anytown, ST 12345',
        emergency_contact_name: 'Susan Wilson',
        emergency_contact_phone: '555-0502',
        insurance_provider: 'Cigna Health',
        insurance_number: 'CH789123456'
    }
];

// Sample conditions data
const conditions = [
    {
        condition_id: 'C001',
        patient_id: 'P001',
        condition_name: 'Type 2 Diabetes',
        condition_type: 'chronic',
        diagnosis_date: '2020-05-15',
        status: 'managed',
        severity: 'moderate',
        description: 'Type 2 diabetes mellitus, well-controlled with medication'
    },
    {
        condition_id: 'C002',
        patient_id: 'P001',
        condition_name: 'Hypertension',
        condition_type: 'chronic',
        diagnosis_date: '2019-03-10',
        status: 'managed',
        severity: 'mild',
        description: 'Essential hypertension, controlled with ACE inhibitor'
    },
    {
        condition_id: 'C003',
        patient_id: 'P002',
        condition_name: 'Asthma',
        condition_type: 'chronic',
        diagnosis_date: '2018-08-20',
        status: 'active',
        severity: 'mild',
        description: 'Allergic asthma, seasonal exacerbations'
    },
    {
        condition_id: 'C004',
        patient_id: 'P003',
        condition_name: 'Coronary Artery Disease',
        condition_type: 'chronic',
        diagnosis_date: '2021-02-14',
        status: 'managed',
        severity: 'moderate',
        description: 'CAD with previous MI, stented LAD'
    },
    {
        condition_id: 'C005',
        patient_id: 'P004',
        condition_name: 'Migraine',
        condition_type: 'chronic',
        diagnosis_date: '2022-01-10',
        status: 'active',
        severity: 'moderate',
        description: 'Chronic migraine with aura'
    }
];

// Sample diagnoses data
const diagnoses = [
    {
        diagnosis_id: 'D001',
        patient_id: 'P001',
        condition_id: 'C001',
        diagnosis_code: 'E11.9',
        diagnosis_name: 'Type 2 diabetes mellitus without complications',
        diagnosis_date: '2020-05-15',
        doctor_name: 'Dr. Sarah Chen',
        doctor_specialty: 'Endocrinology',
        notes: 'Patient presents with elevated blood glucose levels. HbA1c 8.2%.',
        treatment_plan: 'Metformin 500mg BID, lifestyle modifications, regular monitoring',
        follow_up_date: '2024-02-15'
    },
    {
        diagnosis_id: 'D002',
        patient_id: 'P002',
        condition_id: 'C003',
        diagnosis_code: 'J45.9',
        diagnosis_name: 'Asthma, unspecified',
        diagnosis_date: '2018-08-20',
        doctor_name: 'Dr. Mark Thompson',
        doctor_specialty: 'Pulmonology',
        notes: 'Patient reports wheezing and shortness of breath, especially during spring.',
        treatment_plan: 'Albuterol inhaler PRN, Fluticasone daily',
        follow_up_date: '2024-03-01'
    },
    {
        diagnosis_id: 'D003',
        patient_id: 'P003',
        condition_id: 'C004',
        diagnosis_code: 'I25.10',
        diagnosis_name: 'Atherosclerotic heart disease of native coronary artery without angina pectoris',
        diagnosis_date: '2021-02-14',
        doctor_name: 'Dr. Jennifer Martinez',
        doctor_specialty: 'Cardiology',
        notes: 'Patient presented with chest pain. Cardiac catheterization showed 90% LAD stenosis.',
        treatment_plan: 'PCI with drug-eluting stent, dual antiplatelet therapy, statin',
        follow_up_date: '2024-01-20'
    }
];

// Sample appointments data
const appointments = [
    {
        appointment_id: 'A001',
        patient_id: 'P001',
        doctor_name: 'Dr. Sarah Chen',
        doctor_specialty: 'Endocrinology',
        appointment_date: '2024-02-15',
        appointment_time: '10:00:00',
        appointment_type: 'follow-up',
        status: 'scheduled',
        reason_for_visit: 'Diabetes management follow-up',
        notes: 'Review blood glucose logs, adjust medication if needed'
    },
    {
        appointment_id: 'A002',
        patient_id: 'P002',
        doctor_name: 'Dr. Mark Thompson',
        doctor_specialty: 'Pulmonology',
        appointment_date: '2024-03-01',
        appointment_time: '14:30:00',
        appointment_type: 'consultation',
        status: 'scheduled',
        reason_for_visit: 'Asthma control assessment',
        notes: 'Evaluate current medication effectiveness'
    },
    {
        appointment_id: 'A003',
        patient_id: 'P003',
        doctor_name: 'Dr. Jennifer Martinez',
        doctor_specialty: 'Cardiology',
        appointment_date: '2024-01-20',
        appointment_time: '09:15:00',
        appointment_type: 'follow-up',
        status: 'completed',
        reason_for_visit: 'Post-PCI follow-up',
        notes: 'Patient doing well, no chest pain, continue current medications'
    },
    {
        appointment_id: 'A004',
        patient_id: 'P004',
        doctor_name: 'Dr. Lisa Park',
        doctor_specialty: 'Neurology',
        appointment_date: '2024-02-28',
        appointment_time: '11:00:00',
        appointment_type: 'consultation',
        status: 'scheduled',
        reason_for_visit: 'Migraine evaluation',
        notes: 'New patient consultation for chronic headaches'
    },
    {
        appointment_id: 'A005',
        patient_id: 'P005',
        doctor_name: 'Dr. James Wilson',
        doctor_specialty: 'Internal Medicine',
        appointment_date: '2024-02-10',
        appointment_time: '15:45:00',
        appointment_type: 'annual',
        status: 'scheduled',
        reason_for_visit: 'Annual physical examination',
        notes: 'Routine health maintenance visit'
    }
];

// Sample medications data
const medications = [
    {
        medication_id: 'M001',
        patient_id: 'P001',
        medication_name: 'Metformin',
        dosage: '500mg',
        frequency: 'Twice daily',
        start_date: '2020-05-20',
        prescribed_by: 'Dr. Sarah Chen',
        notes: 'For diabetes management'
    },
    {
        medication_id: 'M002',
        patient_id: 'P001',
        medication_name: 'Lisinopril',
        dosage: '10mg',
        frequency: 'Once daily',
        start_date: '2019-03-15',
        prescribed_by: 'Dr. Robert Kim',
        notes: 'For blood pressure control'
    },
    {
        medication_id: 'M003',
        patient_id: 'P002',
        medication_name: 'Albuterol',
        dosage: '90mcg',
        frequency: 'As needed',
        start_date: '2018-08-25',
        prescribed_by: 'Dr. Mark Thompson',
        notes: 'Rescue inhaler for asthma'
    },
    {
        medication_id: 'M004',
        patient_id: 'P002',
        medication_name: 'Fluticasone',
        dosage: '110mcg',
        frequency: 'Twice daily',
        start_date: '2018-08-25',
        prescribed_by: 'Dr. Mark Thompson',
        notes: 'Maintenance inhaler for asthma'
    },
    {
        medication_id: 'M005',
        patient_id: 'P003',
        medication_name: 'Atorvastatin',
        dosage: '40mg',
        frequency: 'Once daily',
        start_date: '2021-02-20',
        prescribed_by: 'Dr. Jennifer Martinez',
        notes: 'For cholesterol management post-PCI'
    }
];

// Function to insert data
function insertData(tableName, data) {
    return new Promise((resolve, reject) => {
        const columns = Object.keys(data[0]).join(', ');
        const placeholders = Object.keys(data[0]).map(() => '?').join(', ');
        const query = `INSERT INTO ${tableName} (${columns}) VALUES (${placeholders})`;
        
        const stmt = db.prepare(query);
        
        db.serialize(() => {
            data.forEach((row) => {
                const values = Object.values(row);
                stmt.run(values, (err) => {
                    if (err) {
                        console.error(`Error inserting into ${tableName}:`, err.message);
                    }
                });
            });
            stmt.finalize((err) => {
                if (err) {
                    reject(err);
                } else {
                    console.log(`Inserted ${data.length} records into ${tableName}`);
                    resolve();
                }
            });
        });
    });
}

// Seed the database
async function seedDatabase() {
    try {
        console.log('Starting database seeding...');
        
        await insertData('patients', patients);
        await insertData('conditions', conditions);
        await insertData('diagnoses', diagnoses);
        await insertData('appointments', appointments);
        await insertData('medications', medications);
        
        console.log('Database seeding completed successfully!');
    } catch (error) {
        console.error('Error seeding database:', error);
    } finally {
        db.close((err) => {
            if (err) {
                console.error('Error closing database:', err.message);
            } else {
                console.log('Database connection closed');
            }
        });
    }
}

// Run the seeding
seedDatabase();
