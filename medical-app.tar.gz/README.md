# Daytona Medical App

A comprehensive medical application with patient database and MCP (Model Context Protocol) server integration for Daytona platform.

## Features

- **Patient Management**: Store and retrieve patient information
- **Appointment Scheduling**: Manage patient appointments
- **Medical Records**: Track conditions, diagnoses, and medications
- **MCP Server**: AI agent integration through Model Context Protocol
- **REST API**: Full REST API for data access
- **SQLite Database**: Lightweight, file-based database

## Database Schema

The application includes the following tables:

- **patients**: Patient demographic and contact information
- **appointments**: Medical appointments and scheduling
- **conditions**: Medical conditions and their status
- **diagnoses**: Medical diagnoses with ICD-10 codes
- **medications**: Patient medication records

## Installation

1. Install dependencies:
```bash
npm install
```

2. Initialize the database:
```bash
npm run init-db
```

3. Seed the database with sample data:
```bash
npm run seed-db
```

## Usage

### Starting the API Server

```bash
npm start
```

The API server will be available at `http://localhost:3000`

### Starting the MCP Server

```bash
node src/mcp/start.js
```

### API Endpoints

- `GET /api/patients` - Get all patients
- `GET /api/patients/:id` - Get specific patient
- `GET /api/appointments` - Get appointments (with filters)
- `POST /api/appointments` - Create new appointment
- `GET /api/conditions` - Get patient conditions
- `GET /api/diagnoses` - Get patient diagnoses
- `GET /api/medications` - Get patient medications

### MCP Server Tools

The MCP server provides the following tools for AI agents:

- `get_patient` - Retrieve patient information
- `get_patients` - Search and list patients
- `get_appointments` - Get appointment data
- `get_conditions` - Get medical conditions
- `get_diagnoses` - Get diagnosis records
- `get_medications` - Get medication records
- `create_appointment` - Schedule new appointments
- `update_appointment` - Update appointment status

## Sample Data

The database is pre-populated with sample data including:

- 5 patients with complete demographic information
- Medical conditions (diabetes, hypertension, asthma, etc.)
- Diagnoses with ICD-10 codes
- Scheduled and completed appointments
- Current and historical medications

## Environment Configuration

Create a `.env` file with the following variables:

```
DAYTONA_API_KEY=your_daytona_api_key_here
DATABASE_URL=sqlite:///medical_app.db
PORT=3000
HOST=localhost
```

## Daytona Integration

This application is designed to work with the Daytona platform:

1. Set your Daytona API key in the `.env` file
2. The MCP server can be used with AI agents in Daytona
3. The REST API provides programmatic access to medical data
4. All data is stored in a local SQLite database

## Development

For development with auto-reload:

```bash
npm run dev
```

## Database Management

- **Initialize**: `npm run init-db`
- **Seed**: `npm run seed-db`
- **Reset**: Delete `medical_app.db` and run init + seed

## Security Notes

- This is a demo application
- In production, implement proper authentication and authorization
- Encrypt sensitive medical data
- Use HTTPS for all communications
- Implement audit logging for medical data access

## License

MIT License
